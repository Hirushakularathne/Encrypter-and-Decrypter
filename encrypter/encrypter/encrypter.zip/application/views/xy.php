<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Encrypter</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="<?php echo ASSETS; ?>css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="<?php echo ASSETS; ?>css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="<?php echo ASSETS; ?>css/style.css" rel="stylesheet">
</head>

<body>

  <!-- Start your project here-->
  <div style="height: 100vh">
    <div class="flex-center flex-column">

      
<!-- Default form subscription -->

<p>This is beta Mode.</p>

<div class="container">
  <div class="row">
    <div class="col-6">
    
    <div class="text-center p-5">

    <p class="h4 mb-4">Encrypter</p>

    

    <br>

    <!-- Name -->
    <input type="text" id="encrypter" class="form-control mb-4" placeholder="Encrypter">

    
    <!-- Sign in button -->
    <button onclick="getEncrypterText()" class="btn btn-info btn-block" type="submit">Encrypter</button>


</div>
    
    </div>
    
    <div class="col-6">
    
    <div class="text-center p-5">

    <p class="h4 mb-4">Decrypter</p>

    

    <br>

    <!-- Name -->
    <input type="text" id="decrypter" class="form-control mb-4" placeholder="Decrypter">

    
    <!-- Sign in button -->
    <button onclick="getDecrypterText()" class="btn btn-info btn-block" type="submit">Decrypter</button>


</div>
    
    </div>
    
      </div>
  </div>



<br>
<!-- Default form subscription -->
      <p class="animated fadeIn text-muted">Hirusha</p>
    </div>
  </div>
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->

  <script>
function getEncrypterText() {
    var x =(document.getElementById("encrypter").value);
    var y = btoa(x);
    alert(y);
}

function getDecrypterText() {
    var p =(document.getElementById("decrypter").value);
    var q = atob(p);
    alert(q);
}

</script>




  <script type="text/javascript" src="<?php echo ASSETS; ?>js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo ASSETS; ?>js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo ASSETS; ?>js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo ASSETS; ?>js/mdb.min.js"></script>
</body>

</html>
